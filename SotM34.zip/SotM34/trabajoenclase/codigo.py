import os
import re
import requests

# ✅ Expresión regular para extraer IP, ruta y código de estado
expresion_regular = r'^(\d{1,3}(?:\.\d{1,3}){3}) - - \[.*?\] "(?:GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH) (\/\S*) HTTP\/\d\.\d" (\d{3})'

# 🧠 Diccionario de significados de códigos HTTP en español
mensajes_http = {
    "200": "Correcto (OK)",
    "201": "Creado",
    "204": "Sin contenido",
    "301": "Movido permanentemente",
    "302": "Encontrado (Redirección)",
    "400": "Solicitud incorrecta",
    "401": "No autorizado",
    "403": "Prohibido",
    "404": "No encontrado",
    "405": "Método no permitido",
    "500": "Error interno del servidor",
    "502": "Puerta de enlace incorrecta",
    "503": "Servicio no disponible",
    "504": "Tiempo de espera agotado"
}

# 🔍 Función para extraer datos del archivo usando la expresión regular
def extraer_datos(expresion, ruta_archivo):
    if ruta_archivo and os.path.exists(ruta_archivo):
        with open(ruta_archivo, "r", encoding="utf-8", errors="ignore") as f:
            contenido = f.read()
        return re.findall(expresion, contenido, re.MULTILINE)
    return []

# 🌎 Función para consultar país y ciudad de cada IP única
def obtener_datos_geolocalizacion(datos):
    resultados = []
    ips_vistas = set()
    url_api = "http://ip-api.com/json/"

    for ip, ruta, codigo in datos:
        if ip in ips_vistas:
            continue
        ips_vistas.add(ip)

        entrada = {"ip": ip, "codigo": codigo, "ruta": ruta}
        try:
            respuesta = requests.get(f"{url_api}{ip}").json()
            entrada["pais"] = respuesta.get("country", "Desconocido")
            entrada["ciudad"] = respuesta.get("city", "Desconocido")
        except:
            entrada["pais"] = "Desconocido"
            entrada["ciudad"] = "Desconocido"

        resultados.append(entrada)
    return resultados

# 📂 Procesar logs: access_log, access_log.1, ..., access_log.6
for i in range(7):
    nombre_archivo = "access_log" if i == 0 else f"access_log.{i}"
    ruta_completa = os.path.join("http", nombre_archivo)

    print(f"\n📁 Analizando archivo: {ruta_completa}")
    coincidencias = extraer_datos(expresion_regular, ruta_completa)

    if coincidencias:
        print(f"🔎 Se encontraron {len(coincidencias)} registros únicos por IP.\n")
        ubicaciones = obtener_datos_geolocalizacion(coincidencias)

        for idx, entrada in enumerate(ubicaciones, 1):
            codigo = entrada["codigo"]
            significado = mensajes_http.get(codigo, "Código desconocido")

            print(f"📌 Registro #{idx}")
            print(f"   🔢 IP         : {entrada['ip']}")
            print(f"   🌍 Ubicación  : {entrada['ciudad']}, {entrada['pais']}")
            print(f"   📄 Ruta       : {entrada['ruta']}")
            print(f"   ⚠️ Código     : {codigo} → {significado}")
            print("─" * 45)
    else:
        print("⚠️ No se encontraron coincidencias en este archivo.")



