import requests
import os
import tarfile
import re
import pandas as pd
from collections import Counter

# Función para extraer datos de archivos usando expresiones regulares
def extractRegularExpresion(regex, file_path):
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as file:
            data = file.read()
        return re.findall(regex, data)
    except Exception as e:
        print(f"Error capturando datos: {e}")
        return None

# Función para extraer archivos comprimidos y analizar logs
def extractLogs(archivo_comprimido, carpeta_destino, regex):
    logs = []
    
    if not os.path.exists(carpeta_destino):
        os.makedirs(carpeta_destino, exist_ok=True)
        with tarfile.open(archivo_comprimido, "r:gz") as tar:
            tar.extractall(carpeta_destino)
        print(f"✅ Archivos extraídos en: {carpeta_destino}")

    archivos = os.listdir(carpeta_destino)
    
    for archivo in archivos:
        ruta_archivo = os.path.join(carpeta_destino, archivo)
        if os.path.isfile(ruta_archivo):
            logs.extend(extractRegularExpresion(regex, ruta_archivo))

    print(f"\n📊 Total de registros capturados: {len(logs)}\n")
    return logs

# Función para obtener información de la IP usando una API
def apiRequestData(data):
    JsonData = []
    if not data:
        print("❌ No hay datos para procesar.")
        return []

    URI = "http://ip-api.com/json/"
    ip_seen = set()

    for ip, path, code in data:
        if ip in ip_seen:
            continue  # Evita consultas repetidas

        ip_seen.add(ip)
        formatData = {"ip": ip, "code": code, 'path': path}

        try:
            response = requests.get(f"{URI}{ip}").json()
            formatData["country"] = response.get("country", "Desconocido")
            formatData["city"] = response.get("city", "Desconocido")
        except Exception as e:
            formatData["country"] = "Error"
            formatData["city"] = "Error"

        JsonData.append(formatData)
    
    return JsonData

# Expresión regular para extraer IP, recurso y código de estado HTTP
regexExpresion = r"^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*?\b[A-Z]{3,7}\b\s(\/\S+).*?(\d{3})"

# Ruta del archivo comprimido y carpeta de extracción
archivo_comprimido = "SotM34-anton.tar.gz"
carpeta_destino = "logs_extraidos"

# Capturar datos de los logs
logs_data = extractLogs(archivo_comprimido, carpeta_destino, regexExpresion)

# Obtener información geográfica de las IPs detectadas
json_result = apiRequestData(logs_data)

# Mostrar los resultados en formato tabla con Pandas
df = pd.DataFrame(json_result)
print(df)

    


