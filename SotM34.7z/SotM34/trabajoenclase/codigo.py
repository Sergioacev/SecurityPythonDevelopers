import os
import re
import requests

# ✅ Expresión regular ajustada a logs Apache/nginx
regex = r'^(\d{1,3}(?:\.\d{1,3}){3}) - - \[.*?\] "(?:GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH) (\/\S*) HTTP\/\d\.\d" (\d{3})'

# 🧠 Función para extraer IP, path y código
def extractFromRegularExpresion(regex, file):
    if file and os.path.exists(file):
        with open(file, "r", encoding="utf-8", errors="ignore") as f:
            data = f.read()
        return re.findall(regex, data, re.MULTILINE)
    return []

# 🌍 Función para obtener país y ciudad de cada IP única
def apiRequestData(data):
    JsonData = []
    ip_seen = set()
    URI = "http://ip-api.com/json/"

    for ip, path, code in data:
        if ip in ip_seen:
            continue
        ip_seen.add(ip)

        formatData = {"ip": ip, "code": code, "path": path}
        try:
            response = requests.get(f"{URI}{ip}").json()
            formatData["country"] = response.get("country")
            formatData["city"] = response.get("city")
        except:
            formatData["country"] = None
            formatData["city"] = None

        JsonData.append(formatData)
    return JsonData

# 🔁 Procesar logs del access_log, access_log.1, ..., access_log.6
for i in range(7):
    archivo = f"access_log" if i == 0 else f"access_log.{i}"
    ruta = os.path.join("http", archivo)

    print(f"\n📂 Analizando: {ruta}")
    resultados = extractFromRegularExpresion(regex, ruta)

    if resultados:
        print(f"🔍 Se encontraron {len(resultados)} registros.")
        ubicaciones = apiRequestData(resultados)
        for entry in ubicaciones:
            print(f"🛜 {entry['ip']} ({entry['country']}, {entry['city']}) => {entry['path']} [{entry['code']}]")
    else:
        print("⚠️ No se encontraron coincidencias.")



